import Carousel from 'react-bootstrap/Carousel';

function Slider() {
  return (
    <Carousel variant="dark">
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/images/im1.png"
          alt="First slide"
        />
        <Carousel.Caption>
          <h5>PlayStation 5</h5>
          <p>Play Has No Limits</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/images/im2.jpg"
          alt="Second slide"
        />
        <Carousel.Caption>
          <h5>Cannon 6D</h5>
          <p>Canon 6D for Landscape Photography</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/images/im3.jpg"
          alt="Third slide"
        />
        <Carousel.Caption>
          <h5>Iphone 14 Pro</h5>
          <p>
          · Meet Dynamic Island. · Mind-blowing detail. · Film like a Pro
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default Slider;