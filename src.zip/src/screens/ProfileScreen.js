import React from 'react'

const ProfileScreen = () => {
  return (
    <div>ProfileScreen</div>
  )
}

export default ProfileScreen