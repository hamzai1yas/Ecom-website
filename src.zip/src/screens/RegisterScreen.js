import React from 'react'

const RegisterScreen = () => {
  return (
    <div>RegisterScreen</div>
  )
}

export default RegisterScreen