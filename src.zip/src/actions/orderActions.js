import axios from 'axios'
import {
    ORDER_CREATE_REQUEST,
    ORDER_CREATE_SUCCESS,
    ORDER_CREATE_FAIL, 
} from '../constants/orderConstants'

export const createOrder = (order) => async (dispatch, getState) => {
    try {
        dispatch({
            type: ORDER_CREATE_REQUEST
        })
    const {
        userLogin: { userInfo },
    } = getState()
    const config = {
        headers: {
            'Content-Tpye': 'application/json',  //it tells what type of data we sending at its end point
            Authorization: `Bearer ${userInfo.token}`, //template literals are used to pass java-script string
        },
    }
    const {data}= await axios.post(`/api/orders`, order, config)  //axios take three things 1st URL, 2nd body/data, 3rd config header
    dispatch({
        type: ORDER_CREATE_SUCCESS,
        payload: data,
    })
    } catch (error) {
        dispatch({
            type: ORDER_CREATE_FAIL,
            payload:
                error.response && error.message.data.message
                    ? error.response.data.message
                    : error.message,
        })
    }
}